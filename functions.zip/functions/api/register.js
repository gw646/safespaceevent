/**
 * POST /api/register
 * 
 * Accepts: application/x-www-form-urlencoded OR application/json
 * - full_name
 * - email
 * - phone
 *
 * Flow:
 *   1. Validate input
 *   2. Ensure D1 table exists (idempotent)
 *   3. Insert registrant
 *   4. Build WiPay payment URL
 *   5. Return { redirect_url } JSON
 *
 * Environment variables required (set in Cloudflare Pages → Settings → Environment Variables):
 *   DB                    — D1 database binding (set in wrangler.toml / Pages binding, not as a string)
 *   WIPAY_ACCOUNT_NUMBER  — Your WiPay merchant account number
 *   WIPAY_API_KEY         — Your WiPay API key
 *   WIPAY_FEE_STRUCTURE   — "customer_pay" | "merchant_absorb" | "split"  (default: customer_pay)
 *   WIPAY_COUNTRY_CODE    — "TT" | "JM" | "BB" | "GY"  (default: TT)
 *   WIPAY_ENVIRONMENT     — "live" | "sandbox"  (default: live)
 *   SITE_URL              — Your site URL, e.g. https://www.themakeddagroup.com
 *   ADMIN_SECRET          — Secret token used to protect /admin
 */

const WIPAY_ENDPOINTS = {
  TT: "https://tt.wipayfinancial.com/plugins/payments/request",
  JM: "https://jm.wipayfinancial.com/plugins/payments/request",
  BB: "https://bb.wipayfinancial.com/plugins/payments/request",
  GY: "https://gy.wipayfinancial.com/plugins/payments/request",
};

export async function onRequestPost(context) {
  const { request, env } = context;

  /* ─── CORS headers ──────────────────────────────────────────────── */
  const corsHeaders = {
    "Access-Control-Allow-Origin":  "*",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
  };

  /* ─── Parse body (supports both content types) ───────────────────── */
  let full_name, email, phone;
  const ct = request.headers.get("content-type") || "";

  try {
    if (ct.includes("application/json")) {
      ({ full_name, email, phone } = await request.json());
    } else {
      // x-www-form-urlencoded (default from landing page)
      const text = await request.text();
      const params = new URLSearchParams(text);
      full_name = params.get("full_name");
      email     = params.get("email");
      phone     = params.get("phone");
    }
  } catch {
    return jsonError("Could not parse request body.", 400, corsHeaders);
  }

  /* ─── Validate ───────────────────────────────────────────────────── */
  if (!full_name?.trim() || !email?.trim() || !phone?.trim()) {
    return jsonError("All fields are required.", 400, corsHeaders);
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return jsonError("Invalid email address.", 400, corsHeaders);
  }

  /* ─── D1 — ensure table exists then insert ───────────────────────── */
  const db = env.DB;
  if (!db) return jsonError("Database binding not configured.", 500, corsHeaders);

  await db.exec(`
    CREATE TABLE IF NOT EXISTS registrants (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      full_name  TEXT    NOT NULL,
      email      TEXT    NOT NULL,
      phone      TEXT    NOT NULL,
      paid       INTEGER NOT NULL DEFAULT 0,
      wipay_ref  TEXT,
      created_at TEXT    NOT NULL DEFAULT (datetime('now'))
    );
  `);

  // Check for duplicate email
  const existing = await db
    .prepare("SELECT id FROM registrants WHERE email = ?")
    .bind(email.toLowerCase().trim())
    .first();

  let registrantId;

  if (existing) {
    registrantId = existing.id;
  } else {
    const insert = await db
      .prepare(
        "INSERT INTO registrants (full_name, email, phone) VALUES (?, ?, ?) RETURNING id"
      )
      .bind(full_name.trim(), email.toLowerCase().trim(), phone.trim())
      .first();
    registrantId = insert.id;
  }

  /* ─── Build WiPay payment URL ────────────────────────────────────── */
  const environment   = env.WIPAY_ENVIRONMENT    || "live";
  const country       = env.WIPAY_COUNTRY_CODE   || "TT";
  const feeStructure  = env.WIPAY_FEE_STRUCTURE  || "customer_pay";
  const accountNumber = env.WIPAY_ACCOUNT_NUMBER;
  const apiKey        = env.WIPAY_API_KEY;
  const siteUrl       = env.SITE_URL             || "https://www.themakeddagroup.com";

  if (!accountNumber) {
    return jsonError("WiPay account number not configured.", 500, corsHeaders);
  }
  if (!apiKey) {
    return jsonError("WiPay API key not configured.", 500, corsHeaders);
  }

  // API key goes as a query param on the endpoint URL
  const wipayEndpoint = `${WIPAY_ENDPOINTS[country] ?? WIPAY_ENDPOINTS.TT}?api_key=${apiKey}`;

  const wipayPayload = new URLSearchParams({
    account_number: accountNumber,
    avs:            "0",
    country_code:   country,
    currency:       country === "TT" ? "TTD" : "USD",
    environment:    environment,
    fee_structure:  feeStructure,
    method:         "credit_card",
    order_id:       `REG-${registrantId}-${Date.now()}`,
    origin:         "SafeSpace",
    response_url:   `${siteUrl}/payment-success?reg=${registrantId}`,
    total:          "340.00", // TTD ≈ $50 USD — adjust if needed
  });

  let paymentUrl;

  try {
    const wipayRes = await fetch(wipayEndpoint, {
      method:  "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body:    wipayPayload.toString(),
    });

    const wipayData = await wipayRes.json();

    if (!wipayData.url) {
      console.error("WiPay response:", JSON.stringify(wipayData));
      return jsonError(
        wipayData.message || "WiPay did not return a payment URL.",
        502,
        corsHeaders
      );
    }

    paymentUrl = wipayData.url;

    // Persist the WiPay transaction ID if available
    if (wipayData.transaction_id) {
      await db
        .prepare("UPDATE registrants SET wipay_ref = ? WHERE id = ?")
        .bind(wipayData.transaction_id, registrantId)
        .run();
    }
  } catch (err) {
    console.error("WiPay fetch error:", err);
    return jsonError("Could not connect to payment gateway.", 502, corsHeaders);
  }

  return new Response(JSON.stringify({ redirect_url: paymentUrl }), {
    status:  200,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

/* Handle CORS preflight */
export async function onRequestOptions() {
  return new Response(null, {
    status: 204,
    headers: {
      "Access-Control-Allow-Origin":  "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  });
}

function jsonError(message, status = 400, extraHeaders = {}) {
  return new Response(JSON.stringify({ error: message }), {
    status,
    headers: { ...extraHeaders, "Content-Type": "application/json" },
  });
}
